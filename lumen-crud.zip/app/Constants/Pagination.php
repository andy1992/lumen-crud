<?php

namespace App\Constants;

class Pagination
{
    const ITEM_PER_PAGE = 10;
}